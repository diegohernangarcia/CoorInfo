<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="target-densitydpi=device-dpi, width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="keywords" content="windows 8, modern style, modern ui, style, modern, css, framework">
    <link href="../Metro/css/modern.css" rel="stylesheet">
    <link href="../estilos/estiloparametros.css" rel="stylesheet">
    <title>Coordinacion Informatica - Ministerio Desarrollo Social - Rio Negro</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body onload="document.forms['principal']['rango'].focus()"> 
<div id="contenedor">
  <div id="cabecera">
  <center><img src="../images/logo.jpg" width="750" height="80" alt="LOGO MINISTERIO" align="middle"></center>
</div>
<br><br><br><br>
<form name="principal" id="principal" action="agregarrango.php" method="post">
<div class="page secondary">
	<div class="page-header">
		<div class="page-header-content">
        	        <h1>Alta Rango<small>beta</small></h1>
        	        <a href="../altas/indexaltas.php" class="back-button big page-back"></a>
        	</div>
        </div>
	<div id="secundario">
			<center>
    			<div class="input-control text span7">
        			<input type="text" name="rango" placeholder="Rango Ej: 10.11.19." text="">
        			<span class="helper"></span>
                                <br><br>
				<button class="bg-color-blueDark">Grabar</button>  
				<br><br>
                        </div>
			</center>
		</form>
	</div>
      	<div id="terciario">
      	</div>
</div>
</center>
</body>
</html>
