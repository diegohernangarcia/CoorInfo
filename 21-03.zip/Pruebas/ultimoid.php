<?php
	include("../BD/BDEquipo.php");
	echo(NuevoRegistro($id));
?>
