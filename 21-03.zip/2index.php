<script language="JavaScript" type="text/javascript">

var pagina="Login/index.php"
function redireccionar() 
{
location.href=pagina
} 
setTimeout ("redireccionar()", 0);

</script>
            
