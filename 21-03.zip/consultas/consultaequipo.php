<?php
    include("equipos/nuevaequipo1.php")

?>
