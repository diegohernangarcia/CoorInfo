<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN"
   "http://www.w3.org/TR/html4/frameset.dtd">
<HTML>
<HEAD>
<TITLE>Un documento simple con marcos</TITLE>
</HEAD>
<FRAMESET cols="25%, 75%">
  <FRAMESET rows="200">
      <FRAME src="izquierda.php">
  </FRAMESET>
  <FRAME src="derecha.php">
  <NOFRAMES>
     
  </NOFRAMES>
</FRAMESET>
</HTML>