<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="target-densitydpi=device-dpi, width=device-width, initial-scale=1.0, maximum-scale=1">
      
    <link href="../Metro/css/modern.css" rel="stylesheet">
    <link href="../estilos/consultas.css" rel="stylesheet">
    
    
        
    <title>Coordinacion Informatica</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body bgcolor="#FFFFFF" onload="document.forms['principal']['busqueda'].focus()">
     <div id="menu">
  .     <form name="principal" id="principal" action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
            <br>
            <center><h3><small>Ingrese el Codigo de Barras</small></h3></center>
            
            <div class="input-control text"  span3>
                <input type="text" name="busqueda" id="oficina">
                <span class="helper"></span>
            </div>
            <center>
                <button class="bg-color-blue">Buscar</button>    
            </center>
        </form>
     </div>
      <div id="contenido">    
            <div id="principal">
                <br><br>
                <center><h3> <? echo ("CASA" ); ?> </h3> </center>
            </div>
          
        </div>
   
        

</body>
    
<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
