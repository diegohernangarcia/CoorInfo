<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="target-densitydpi=device-dpi, width=device-width, initial-scale=1.0, maximum-scale=1">
      
    <link href="../Metro/css/modern.css" rel="stylesheet">
    <link href="../estilos/principal.css" rel="stylesheet">
    
    
        
    <title>Coordinacion Informatica</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!-- <style type="text/css">
body,td,th {
	font-family: "Segoe UI Semilight", "Open Sans", Verdana, Arial, Helvetica, sans-serif;
}
body {
	background-image: url(../images/fondo.jpg);
}
</style> -->
</head>
<body bgcolor="#FFFFFF" onload="document.forms['principal']['usuario'].focus()">
<div id="contenedor">
  <div id="cabecera">
  <center><img src="../images/logo.jpg" width="750" height="80" alt="LOGO MINISTERIO" align="middle"></center>
  </div>

  <div id="menu">
  .
   
  </div>
 
  <div id="contenido">
    <div id="principal">
    <br><br><br><br>
    		<h1> Bienvenido </h1>
            <h2> Coordinacion Informatica </h2>
    	    <div class="image-collection">

            </div>
    </div>
 
    <div id="secundario">
    <br><br><br><br><br>
    <h2>Ingreso Al Sistema</h2>
    <br><br>
    <form name="principal" id="principal" action="/CoordInfo/Login/login.php" method="post">
    <div class="input-control text">
        <input type="text" name="usuario"   placeholder="Nombre de Usuario" align="center">
        <span class="helper"></span>
    </div>
    <div class="input-control password">
    	<input type="password" name="clave" placeholder="Ingrese Contraseña">
        <span class="helper"></span>
     </div>
	    <button class="bg-color-blue">Iniciar Sesion</button>    
    </div>
  </div>
  </form>
  <div id="pie">
      <br><br><br><br><br>
        <center>
            <H3><small>Preferimos</small></H3>
            <img src="../images/firefox.png" alt="LOGO MINISTERIO" align="middle">
        </center>

      
  </div>
</div> 
	
    
    
    
	
</body>
</html>
