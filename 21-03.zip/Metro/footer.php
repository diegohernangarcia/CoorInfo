<div class="navigation-bar">
    <div class="navigation-bar-inner bg-color-darken">
        <ul style="display: block">
            <li class="no-hover">2012, Metro UI CSS &copy; by <a class="fg-color-blueLight" href="mailto:sergey@pimenov.com.ua">Sergey Pimenov</a></li>
        </ul>
    </div>
</div>
