<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body>
	<link href="../Metro/css/modern.css" rel="stylesheet">
	<div class="message-dialog bg-color-red fg-color-white">
            <p>El ip que desea agregar esta siendo utilizado por una impresora</p>
            <button class="place-right" onClick="history.back()	">Volver</button>
            <button class="place-right" onClick="location.href='proximamente.php'">Ver Registro</button>
        </div>
	
	
	
</body>
</hmtl>

