<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body>
	<link href="../Metro/css/modern.css" rel="stylesheet">
	<div class="message-dialog bg-color-green fg-color-white">
            <p>Incidente agregado correctamente</p>
            <button class="place-right" onClick="location.href='../incidencias/nuevaequipo1.php'">Agregar Otro</button>
            <button class="place-right" onClick="location.href='../menus/index.php'">Salir</button>

        </div>
	
	
	
</body>
</hmtl>


