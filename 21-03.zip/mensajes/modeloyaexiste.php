<html>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <body>
        <link href="../Metro/css/modern.css" rel="stylesheet">
        <div class="message-dialog bg-color-red fg-color-white">
            <p>Este modelo ya esta cargado en el sistema</p>
             <button class="place-right" onClick="location.href='nuevomodelo.php'">Volver</button>
        </div> 
    </body>
</hmtl>

