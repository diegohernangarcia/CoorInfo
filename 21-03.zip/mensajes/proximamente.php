<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body>
	<link href="../Metro/css/modern.css" rel="stylesheet">
	<div class="message-dialog bg-color-green fg-color-white">
            <p>Proximamente</p>
            <button class="place-right" onClick="history.back()">Volver</button>
        </div>
	
	
	
	
	
</body>
</hmtl>

