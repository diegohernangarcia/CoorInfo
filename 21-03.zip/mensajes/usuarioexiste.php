<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body>
	<link href="../Metro/css/modern.css" rel="stylesheet">
	<div class="message-dialog bg-color-red fg-color-white">
            <p>El usuario que desea agregar, ya posee un equipo asignado</p>
             <button class="place-right" onClick="window.open('../altas/ipduplicada/usuarioduplicado.php','Error','width=1000, height=250, toolbar=0, directories=0');  "target="_blank">Ver Registro</button>
            <button class="place-right" onClick="history.back()">Volver</button>
         </div>
	
	
	
</body>
</hmtl>

