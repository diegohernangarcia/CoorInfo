<html>
    <head>
            
<script type="text/javascript">
    function cerrar () { 
   	window.opener.document.location.reload();
   	window.close();
        //alert("PUCHO");
} 
</script> 
</head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<body>
	<link href="../../Metro/css/modern.css" rel="stylesheet">
	<div class="message-dialog bg-color-green fg-color-white">
            <p>Modificado Correctamente</p>
             <button class="place-right" onClick="return cerrar(this);">Atras</button> 
             
        </div>
	
	
	
</body>
</hmtl>

